﻿namespace Alura.Filmes.App.Negocio
{
    public enum ClassificacaoIndicativa
    {
        Livre,          //G
        MaioresQue10,   //PG
        MaioresQue13,   //PG-13
        MaioresQue14,   //R
        MaioresQue18    //NC-17
    }
}
